import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class AddMenuItemDialog extends StatefulWidget {
  const AddMenuItemDialog({super.key});

  @override
  State<AddMenuItemDialog> createState() => _AddMenuItemDialogState();
}

class _AddMenuItemDialogState extends State<AddMenuItemDialog> {
  final TextEditingController itemNameController = TextEditingController();
  final TextEditingController priceController = TextEditingController();

  String category = 'other';
  bool isSaving = false;
  String? errorMessage;

  Future<String> _generateNextItemId() async {
    final snapshot = await FirebaseFirestore.instance.collection('menu_items').get();

    var maxNumber = 0;
    final regex = RegExp(r'^ITEM(\d+)$');

    for (final doc in snapshot.docs) {
      final match = regex.firstMatch(doc.id.trim().toUpperCase());
      if (match == null) continue;

      final number = int.tryParse(match.group(1) ?? '0') ?? 0;
      if (number > maxNumber) {
        maxNumber = number;
      }
    }

    final nextNumber = maxNumber + 1;
    return 'ITEM${nextNumber.toString().padLeft(3, '0')}';
  }

  Future<void> createMenuItem() async {
    final itemName = itemNameController.text.trim();
    final priceText = priceController.text.trim();

    if (itemName.isEmpty || priceText.isEmpty) {
      setState(() {
        errorMessage = 'Please fill all required fields.';
      });
      return;
    }

    final estimatedPrice = num.tryParse(priceText);
    if (estimatedPrice == null) {
      setState(() {
        errorMessage = 'Estimated price must be a valid number.';
      });
      return;
    }

    try {
      setState(() {
        isSaving = true;
        errorMessage = null;
      });

      final docId = await _generateNextItemId();

      await FirebaseFirestore.instance.collection('menu_items').doc(docId).set({
        'item_name': itemName,
        'category': category,
        'estimated_price': estimatedPrice,
        'status': 'active',
        'is_active': true,
        'created_at': FieldValue.serverTimestamp(),
        'updated_at': FieldValue.serverTimestamp(),
      });

      if (!mounted) return;
      Navigator.pop(context);
    } catch (e) {
      setState(() {
        errorMessage = 'Failed to create menu item: $e';
        isSaving = false;
      });
    }
  }

  @override
  void dispose() {
    itemNameController.dispose();
    priceController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Add Menu Item'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: itemNameController,
              textCapitalization: TextCapitalization.words,
              decoration: const InputDecoration(
                labelText: 'Item Name',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              initialValue: category,
              decoration: const InputDecoration(
                labelText: 'Category',
                border: OutlineInputBorder(),
              ),
              items: const [
                DropdownMenuItem(value: 'bread', child: Text('bread')),
                DropdownMenuItem(value: 'rice', child: Text('rice')),
                DropdownMenuItem(value: 'main_course', child: Text('main_course')),
                DropdownMenuItem(value: 'side_item', child: Text('side_item')),
                DropdownMenuItem(value: 'salad', child: Text('salad')),
                DropdownMenuItem(value: 'sauce', child: Text('sauce')),
                DropdownMenuItem(value: 'dessert', child: Text('dessert')),
                DropdownMenuItem(value: 'beverage', child: Text('beverage')),
                DropdownMenuItem(value: 'hot_beverage', child: Text('hot_beverage')),
                DropdownMenuItem(value: 'other', child: Text('other')),
              ],
              onChanged: (value) {
                if (value == null) return;
                setState(() {
                  category = value;
                });
              },
            ),
            const SizedBox(height: 12),
            TextField(
              controller: priceController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                labelText: 'Estimated Price',
                prefixText: 'Rs ',
                border: OutlineInputBorder(),
              ),
            ),
            if (errorMessage != null) ...[
              const SizedBox(height: 12),
              Text(
                errorMessage!,
                style: const TextStyle(color: Colors.red),
              ),
            ],
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: isSaving ? null : () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: isSaving ? null : createMenuItem,
          child: Text(isSaving ? 'Saving...' : 'Create'),
        ),
      ],
    );
  }
}
