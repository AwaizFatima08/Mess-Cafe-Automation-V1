import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class WeeklyMenuTemplateScreen extends StatefulWidget {
  final String userEmail;

  const WeeklyMenuTemplateScreen({
    super.key,
    required this.userEmail,
  });

  @override
  State<WeeklyMenuTemplateScreen> createState() =>
      _WeeklyMenuTemplateScreenState();
}

class _WeeklyMenuTemplateScreenState extends State<WeeklyMenuTemplateScreen> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  final TextEditingController templateNameController = TextEditingController();
  final FocusNode templateNameFocusNode = FocusNode();

  final List<String> weekDays = const [
    'monday',
    'tuesday',
    'wednesday',
    'thursday',
    'friday',
    'saturday',
    'sunday',
  ];

  final List<Map<String, String>> mealTypes = const [
    {'value': 'breakfast', 'label': 'Breakfast'},
    {'value': 'lunch', 'label': 'Lunch'},
    {'value': 'dinner', 'label': 'Dinner'},
  ];

  String selectedMealType = 'breakfast';
  String savedTemplateFilter = 'all';
  String? editingTemplateId;
  bool isSaving = false;
  String? statusMessage;

  final Map<String, List<String>> daySelections = {
    'monday': <String>[],
    'tuesday': <String>[],
    'wednesday': <String>[],
    'thursday': <String>[],
    'friday': <String>[],
    'saturday': <String>[],
    'sunday': <String>[],
  };

  final Map<String, bool> dayExpandedState = {
    'monday': false,
    'tuesday': false,
    'wednesday': false,
    'thursday': false,
    'friday': false,
    'saturday': false,
    'sunday': false,
  };

  @override
  void dispose() {
    templateNameController.dispose();
    templateNameFocusNode.dispose();
    super.dispose();
  }

  String formatLabel(String value) {
    return value
        .split('_')
        .map((word) {
          if (word.isEmpty) return word;
          return '${word[0].toUpperCase()}${word.substring(1)}';
        })
        .join(' ');
  }

  bool isItemActive(Map<String, dynamic> data) {
    return data['is_active'] == true ||
        (data['status'] ?? '').toString().trim().toLowerCase() == 'active';
  }

  bool isTemplateActive(Map<String, dynamic> data) {
    return data['is_active'] == true ||
        (data['status'] ?? '').toString().trim().toLowerCase() == 'active';
  }

  Future<String> _generateNextTemplateId() async {
    final snapshot = await _firestore.collection('weekly_menu_templates').get();

    int maxNumber = 0;
    final regex = RegExp(r'^WMT(\d+)$');

    for (final doc in snapshot.docs) {
      final match = regex.firstMatch(doc.id.trim().toUpperCase());
      if (match == null) continue;

      final number = int.tryParse(match.group(1) ?? '0') ?? 0;
      if (number > maxNumber) {
        maxNumber = number;
      }
    }

    return 'WMT${(maxNumber + 1).toString().padLeft(4, '0')}';
  }

  void resetForm() {
    templateNameController.clear();
    selectedMealType = 'breakfast';
    editingTemplateId = null;
    statusMessage = null;

    for (final day in weekDays) {
      daySelections[day] = <String>[];
      dayExpandedState[day] = false;
    }

    if (mounted) {
      setState(() {});
    }
  }

  List<String> _normalizeStringList(dynamic raw) {
    if (raw is! List) return <String>[];

    return raw
        .map((e) => e.toString().trim())
        .where((e) => e.isNotEmpty)
        .toList();
  }

  Future<void> saveTemplate() async {
    final templateName = templateNameController.text.trim();

    if (templateName.isEmpty) {
      setState(() {
        statusMessage = 'Template name is required.';
      });
      return;
    }

    if (!['breakfast', 'lunch', 'dinner'].contains(selectedMealType)) {
      setState(() {
        statusMessage = 'Please select a valid meal type.';
      });
      return;
    }

    final hasAnySelection =
        weekDays.any((day) => (daySelections[day] ?? []).isNotEmpty);

    if (!hasAnySelection) {
      setState(() {
        statusMessage = 'Select at least one item for at least one day.';
      });
      return;
    }

    try {
      setState(() {
        isSaving = true;
        statusMessage = null;
      });

      final now = FieldValue.serverTimestamp();
      final docId = editingTemplateId ?? await _generateNextTemplateId();

      final payload = <String, dynamic>{
        'template_name': templateName,
        'meal_type': selectedMealType,
        'is_active': true,
        'status': 'active',
        'updated_at': now,
      };

      if (editingTemplateId == null) {
        payload['created_at'] = now;
      }

      for (final day in weekDays) {
        payload[day] = List<String>.from(daySelections[day] ?? <String>[]);
      }

      await _firestore
          .collection('weekly_menu_templates')
          .doc(docId)
          .set(payload, SetOptions(merge: true));

      if (!mounted) return;

      final wasEdit = editingTemplateId != null;

      setState(() {
        isSaving = false;
        statusMessage = wasEdit
            ? 'Template updated successfully.'
            : 'Template created successfully with ID $docId.';
      });

      resetForm();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        isSaving = false;
        statusMessage = 'Failed to save template: $e';
      });
    }
  }

  void loadTemplateForEdit(QueryDocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data();

    templateNameController.text =
        (data['template_name'] ?? '').toString().trim();
    selectedMealType = (data['meal_type'] ?? 'breakfast').toString().trim();
    editingTemplateId = doc.id;
    statusMessage = null;

    for (final day in weekDays) {
      daySelections[day] = _normalizeStringList(data[day]);
      dayExpandedState[day] = false;
    }

    setState(() {});

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      templateNameFocusNode.requestFocus();
    });
  }

  Future<void> toggleTemplateActive(
    QueryDocumentSnapshot<Map<String, dynamic>> doc,
  ) async {
    try {
      final data = doc.data();
      final currentlyActive = isTemplateActive(data);
      final nextActive = !currentlyActive;

      await doc.reference.update({
        'is_active': nextActive,
        'status': nextActive ? 'active' : 'inactive',
        'updated_at': FieldValue.serverTimestamp(),
      });

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            nextActive ? 'Template activated.' : 'Template deactivated.',
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to update template: $e')),
      );
    }
  }

  Widget _buildStaticFormSection() {
    final inEditMode = editingTemplateId != null;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              inEditMode
                  ? 'Edit Weekly Menu Template'
                  : 'Create Weekly Menu Template',
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            if (inEditMode) ...[
              const SizedBox(height: 8),
              Text(
                'Editing template ID: $editingTemplateId',
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 4),
              TextButton.icon(
                onPressed: resetForm,
                icon: const Icon(Icons.close),
                label: const Text('Cancel Edit'),
              ),
            ],
            const SizedBox(height: 16),
            TextField(
              controller: templateNameController,
              focusNode: templateNameFocusNode,
              decoration: const InputDecoration(
                labelText: 'Template Name',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              initialValue: selectedMealType,
              decoration: const InputDecoration(
                labelText: 'Meal Type',
                border: OutlineInputBorder(),
              ),
              items: mealTypes
                  .map(
                    (type) => DropdownMenuItem<String>(
                      value: type['value'],
                      child: Text(type['label']!),
                    ),
                  )
                  .toList(),
              onChanged: (value) {
                if (value == null) return;
                setState(() {
                  selectedMealType = value;
                });
              },
            ),
            if (statusMessage != null) ...[
              const SizedBox(height: 16),
              Text(
                statusMessage!,
                style: TextStyle(
                  color: statusMessage!.toLowerCase().contains('failed') ||
                          statusMessage!.toLowerCase().contains('required')
                      ? Colors.red
                      : Colors.green,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildDayCard({
    required String day,
    required List<QueryDocumentSnapshot<Map<String, dynamic>>> activeMenuItems,
  }) {
    final selectedIds = daySelections[day] ?? <String>[];
    final isExpanded = dayExpandedState[day] ?? false;

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ExpansionTile(
        key: PageStorageKey('weekly-template-$day'),
        initiallyExpanded: isExpanded,
        maintainState: true,
        onExpansionChanged: (expanded) {
          setState(() {
            dayExpandedState[day] = expanded;
          });
        },
        title: Text(formatLabel(day)),
        subtitle: Text(
          selectedIds.isEmpty
              ? 'No items selected'
              : '${selectedIds.length} item(s) selected',
        ),
        children: [
          if (activeMenuItems.isEmpty)
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('No active menu items found.'),
            )
          else
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
              child: Column(
                children: activeMenuItems.map((doc) {
                  final data = doc.data();
                  final itemId = doc.id;
                  final itemName = (data['item_name'] ?? itemId).toString().trim();
                  final category =
                      (data['category'] ?? 'other').toString().trim();
                  final checked = selectedIds.contains(itemId);

                  return CheckboxListTile(
                    dense: true,
                    controlAffinity: ListTileControlAffinity.leading,
                    value: checked,
                    title: Text(itemName),
                    subtitle: Text('$itemId • $category'),
                    onChanged: (value) {
                      setState(() {
                        final updated =
                            List<String>.from(daySelections[day] ?? <String>[]);

                        if (value == true) {
                          if (!updated.contains(itemId)) {
                            updated.add(itemId);
                          }
                        } else {
                          updated.remove(itemId);
                        }

                        daySelections[day] = updated;
                        dayExpandedState[day] = true;
                      });
                    },
                  );
                }).toList(),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildSavedTemplateCard(
    QueryDocumentSnapshot<Map<String, dynamic>> doc,
  ) {
    final data = doc.data();

    final templateName =
        (data['template_name'] ?? '').toString().trim().isEmpty
            ? '(Untitled Template)'
            : (data['template_name'] ?? '').toString().trim();

    final mealType =
        (data['meal_type'] ?? '').toString().trim().isEmpty
            ? '(Missing Meal Type)'
            : (data['meal_type'] ?? '').toString().trim();

    final active = isTemplateActive(data);

    int totalItems = 0;
    for (final day in weekDays) {
      totalItems += _normalizeStringList(data[day]).length;
    }

    return Card(
      key: ValueKey(doc.id),
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Wrap(
              spacing: 12,
              runSpacing: 12,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                Text(
                  templateName,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Chip(label: Text(active ? 'Active' : 'Inactive')),
              ],
            ),
            const SizedBox(height: 8),
            Text('Meal Type: ${formatLabel(mealType)}'),
            Text('Document ID: ${doc.id}'),
            Text('Total selected items: $totalItems'),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                OutlinedButton.icon(
                  onPressed: () => loadTemplateForEdit(doc),
                  icon: const Icon(Icons.edit),
                  label: const Text('Edit'),
                ),
                OutlinedButton.icon(
                  onPressed: () => toggleTemplateActive(doc),
                  icon: Icon(
                    active ? Icons.visibility_off : Icons.visibility,
                  ),
                  label: Text(active ? 'Deactivate' : 'Activate'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDynamicDataSection(
    List<QueryDocumentSnapshot<Map<String, dynamic>>> activeMenuItems,
    List<QueryDocumentSnapshot<Map<String, dynamic>>> templateDocs,
  ) {
    var filteredDocs = List<QueryDocumentSnapshot<Map<String, dynamic>>>.from(
      templateDocs,
    );

    filteredDocs.sort((a, b) => a.id.compareTo(b.id));

    if (savedTemplateFilter != 'all') {
      filteredDocs = filteredDocs.where((doc) {
        final mealType = (doc.data()['meal_type'] ?? '').toString().trim();
        return mealType == savedTemplateFilter;
      }).toList();
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Text(
              'Day-wise Item Selection',
              style: Theme.of(context).textTheme.titleMedium,
            ),
          ),
        ),
        const SizedBox(height: 12),
        ...weekDays.map(
          (day) => _buildDayCard(
            day: day,
            activeMenuItems: activeMenuItems,
          ),
        ),
        const SizedBox(height: 6),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: isSaving ? null : saveTemplate,
            icon: const Icon(Icons.save),
            label: Text(
              isSaving
                  ? 'Saving...'
                  : editingTemplateId == null
                      ? 'Create Template'
                      : 'Update Template',
            ),
          ),
        ),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Wrap(
              spacing: 12,
              runSpacing: 12,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                const Text(
                  'Saved Templates',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(
                  width: 220,
                  child: DropdownButtonFormField<String>(
                    initialValue: savedTemplateFilter,
                    decoration: const InputDecoration(
                      labelText: 'Filter',
                      border: OutlineInputBorder(),
                    ),
                    items: const [
                      DropdownMenuItem(value: 'all', child: Text('All')),
                      DropdownMenuItem(
                        value: 'breakfast',
                        child: Text('Breakfast'),
                      ),
                      DropdownMenuItem(value: 'lunch', child: Text('Lunch')),
                      DropdownMenuItem(value: 'dinner', child: Text('Dinner')),
                    ],
                    onChanged: (value) {
                      if (value == null) return;
                      setState(() {
                        savedTemplateFilter = value;
                      });
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        if (filteredDocs.isEmpty)
          const Card(
            child: Padding(
              padding: EdgeInsets.all(20),
              child: Text('No templates found.'),
            ),
          )
        else
          ...filteredDocs.map(_buildSavedTemplateCard),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Weekly Menu Templates'),
      ),
      body: Column(
        children: [
          Expanded(
            flex: 0,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
              child: Column(
                children: [
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text('Logged in as: ${widget.userEmail}'),
                  ),
                  const SizedBox(height: 16),
                  _buildStaticFormSection(),
                ],
              ),
            ),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: _firestore.collection('menu_items').snapshots(),
              builder: (context, itemSnapshot) {
                if (itemSnapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }

                if (itemSnapshot.hasError) {
                  return Center(
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Text(
                        'Failed to load menu items: ${itemSnapshot.error}',
                      ),
                    ),
                  );
                }

                final activeMenuItems = (itemSnapshot.data?.docs ?? [])
                    .where((doc) => isItemActive(doc.data()))
                    .toList()
                  ..sort((a, b) {
                    final aName =
                        (a.data()['item_name'] ?? a.id).toString().toLowerCase();
                    final bName =
                        (b.data()['item_name'] ?? b.id).toString().toLowerCase();
                    return aName.compareTo(bName);
                  });

                return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                  stream:
                      _firestore.collection('weekly_menu_templates').snapshots(),
                  builder: (context, templateSnapshot) {
                    if (templateSnapshot.connectionState ==
                        ConnectionState.waiting) {
                      return const Center(child: CircularProgressIndicator());
                    }

                    if (templateSnapshot.hasError) {
                      return Center(
                        child: Padding(
                          padding: const EdgeInsets.all(20),
                          child: Text(
                            'Failed to load templates: ${templateSnapshot.error}',
                          ),
                        ),
                      );
                    }

                    final templateDocs = templateSnapshot.data?.docs ?? [];

                    return ListView(
                      padding: const EdgeInsets.all(16),
                      children: [
                        _buildDynamicDataSection(activeMenuItems, templateDocs),
                      ],
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
